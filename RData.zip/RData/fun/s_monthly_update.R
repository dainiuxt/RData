dtudataload()
dtudataproces()
dtudatasubset()
dtutotals()
