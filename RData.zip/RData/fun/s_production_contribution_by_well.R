dtu_piechart <- function(date, data, ...)
{
  chartdate <- as.Date(date, "%Y-%m-%d")
  labyear <- paste(year(chartdate), month(chartdate), sep = "-")
  piedata <- subset(data, data$Date_m==chartdate)
  piedata$percentage <- round(piedata$QOM/sum(piedata$QOM)*100)
  piedata$labels <- paste(piedata$Well_N, piedata$percentage, "%", '\n', round(piedata$QOD, digits = 1), "m3/d", sep = " ")
  piedata <- piedata[order(-piedata$percentage),]
  charttitle <- paste("Oil production contribution as of ", labyear)
  pie(piedata$QOM, labels = piedata$labels, radius = 1.02, clockwise = TRUE, main = charttitle)
}
