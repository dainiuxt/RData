dtu_exportpng <- function (filename, ...)
{
  png(filename = filename, width = 8, height = 5, units = "in", res=300)
}
