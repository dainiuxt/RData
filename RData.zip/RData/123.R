Kretinga <- setkey(setDT(Kretinga), Date_m, Well_N)[
CJ(Date_m=seq(min(Date_m), max(Date_m), by='1 month'),
Well_N=unique(Well_N))][is.na(QOM), QOM:=0][is.na(QWM), QWM:=0][is.na(QFM), QFM:=0][is.na(QIW), QIW:=0][is.na(QOD), QOD:=0][is.na(QWD), QWD:=0][is.na(QFD), QFD:=0][order(Well_N)]
mindate <- min(as.Date(Kretinga$Date_m))
minyear <- year(mindate)+1
minlab <- as.Date(paste(minyear, 01, 01, sep = "-"))
maxdate <- max(as.Date(Kretinga$Date_m))
maxyear <- year(maxdate)
maxlab <- as.Date(paste(maxyear, 01, 01, sep = "-"))
Kretinga <- Kretinga[order(as.Date(Kretinga$Date_m, format="%Y-%m-%d")),]
Kretinga = Kretinga %>% group_by(Well_N) %>% mutate(CumOil=cumsum(QOM))
Kretinga = Kretinga %>% group_by(Well_N) %>% mutate(CumWat=cumsum(QWM))
Kretinga = Kretinga %>% group_by(Well_N) %>% mutate(CumF=cumsum(QFM))
Kretinga = Kretinga %>% group_by(Well_N) %>% mutate(CumInj=cumsum(QIW))
Kretinga = Kretinga %>% group_by(Date_m) %>% mutate(QOMF = sum(QOM))
Kretinga = Kretinga %>% group_by(Date_m) %>% mutate(QWMF = sum(QWM))
Kretinga = Kretinga %>% group_by(Well_N) %>% mutate(CumOilF=cumsum(QOMF))
pkrt8r <- dtuwellprodchartow(Kretinga, "KRT8R")
load("~/Rdata/.RData")
#loading required libraries
library(data.table)
library(ggplot2)
library(grid)
library(magrittr)
library(dplyr)
library(gtable)
library(ggthemes)
library(gridBase)
library(png)
library(gridExtra)
library(scales)
Genciai <- GEN.sub
Genciai <- setkey(setDT(Genciai), Date_m, Well_N)[
CJ(Date_m=seq(min(Date_m), max(Date_m), by='1 month'),
Well_N=unique(Well_N))][is.na(QOM), QOM:=0][is.na(QWM), QWM:=0][is.na(QFM), QFM:=0][is.na(QIW), QIW:=0][is.na(QOD), QOD:=0][is.na(QWD), QWD:=0][is.na(QFD), QFD:=0][order(Well_N)]
View(Genciai)
head(Genciai)
mindate <- as.Date(2015-01-01)
mindate <- as.Date(2015-01-01, sep = "-")
mindate <- min(as.Date(Genciai$Date_m))
minyear <- year(mindate)+1
minlab <- as.Date(paste(minyear, 01, 01, sep = "-"))
maxdate <- max(as.Date(Genciai$Date_m))
maxyear <- year(maxdate)
maxlab <- as.Date(paste(maxyear, 01, 01, sep = "-"))
Genciai <- Genciai[order(as.Date(Genciai$Date_m, format="%Y-%m-%d")),]
Genciai = Genciai %>% group_by(Well_N) %>% mutate(CumOil=cumsum(QOM))
Genciai = Genciai %>% group_by(Well_N) %>% mutate(CumWat=cumsum(QWM))
Genciai = Genciai %>% group_by(Well_N) %>% mutate(CumF=cumsum(QFM))
Genciai = Genciai %>% group_by(Well_N) %>% mutate(CumInj=cumsum(QIW))
Genciai = Genciai %>% group_by(Date_m) %>% mutate(QOMF = sum(QOM))
Genciai = Genciai %>% group_by(Date_m) %>% mutate(QWMF = sum(QWM))
Genciai = Genciai %>% group_by(Well_N) %>% mutate(CumOilF=cumsum(QOMF))
minlab <- as.Date(paste(2015, 01, 01, sep = "-"))
Genciai <- Genciai[order(as.Date(Genciai$Date_m, format="%Y-%m-%d")),]
Genciai = Genciai %>% group_by(Well_N) %>% mutate(CumOil=cumsum(QOM))
Genciai = Genciai %>% group_by(Well_N) %>% mutate(CumWat=cumsum(QWM))
Genciai = Genciai %>% group_by(Well_N) %>% mutate(CumF=cumsum(QFM))
Genciai = Genciai %>% group_by(Well_N) %>% mutate(CumInj=cumsum(QIW))
Genciai = Genciai %>% group_by(Date_m) %>% mutate(QOMF = sum(QOM))
Genciai = Genciai %>% group_by(Date_m) %>% mutate(QWMF = sum(QWM))
Genciai = Genciai %>% group_by(Well_N) %>% mutate(CumOilF=cumsum(QOMF))
pgen3 <- dtuwellprodchartow(Genciai, "GEN3")
pgen13h <- dtuwellprodchartow(Genciai, "GEN13H")
pgen6 <- dtuwellprodchartow(Genciai, "GEN6")
pgen8h <- dtuwellprodchartow(Genciai, "GEN8H")
install.packages(c("boot", "curl", "ggplot2", "ggthemes", "gridExtra", "gtable", "Hmisc", "latticeExtra", "munsell", "mvtnorm", "nlme", "nnet", "openssl", "RCurl", "rmarkdown", "scales", "sfsmisc", "shiny", "withr", "xtable"))
load("~/Rdata/.RData")
#loading required libraries
library(data.table)
library(ggplot2)
library(grid)
library(magrittr)
library(dplyr)
library(gtable)
library(ggthemes)
library(gridBase)
library(png)
library(gridExtra)
library(scales)
Ablinga <- ABL.sub
Ablinga <- setkey(setDT(Ablinga), Date_m, Well_N)[
CJ(Date_m=seq(min(Date_m), max(Date_m), by='1 month'),
Well_N=unique(Well_N))][is.na(QOM), QOM:=0][is.na(QWM), QWM:=0][is.na(QFM), QFM:=0][is.na(QIW), QIW:=0][is.na(QOD), QOD:=0][is.na(QWD), QWD:=0][is.na(QFD), QFD:=0][order(Well_N)]
mindate <- min(as.Date(Ablinga$Date_m))
minyear <- year(mindate)+1
minlab <- as.Date(paste(minyear, 01, 01, sep = "-"))
maxdate <- max(as.Date(Ablinga$Date_m))
maxyear <- year(maxdate)+1
maxlab <- as.Date(paste(maxyear, 01, 01, sep = "-"))
Ablinga <- Ablinga[order(as.Date(Ablinga$Date_m, format="%Y-%m-%d")),]
Ablinga = Ablinga %>% group_by(Well_N) %>% mutate(CumOil=cumsum(QOM))
Ablinga = Ablinga %>% group_by(Well_N) %>% mutate(CumWat=cumsum(QWM))
Ablinga = Ablinga %>% group_by(Well_N) %>% mutate(CumF=cumsum(QFM))
Ablinga = Ablinga %>% group_by(Well_N) %>% mutate(CumInj=cumsum(QIW))
Ablinga = Ablinga %>% group_by(Date_m) %>% mutate(QOMF = sum(QOM))
Ablinga = Ablinga %>% group_by(Date_m) %>% mutate(QWMF = sum(QWM))
Ablinga = Ablinga %>% group_by(Well_N) %>% mutate(CumOilF=cumsum(QOMF))
pabl7 <- dtuwellprodchartow(Ablinga, "ABL7")
View(Nausodis)
source('~/Rdata/scripts/functions.R', echo=TRUE)
dtumonthly()
source('~/Rdata/overview-charts/Ablinga-overview-chart.R', echo=TRUE)
source('~/Rdata/overview-charts/generate-overview.R', echo=TRUE)
dtumonthly()
View(monthly)
dtumonthly()
source('~/Rdata/overview-charts/generate-overview.R', echo=TRUE)
source('~/Rdata/scripts/functions.R', echo=TRUE)
dtumonthly()
source('~/Rdata/overview-charts/generate-overview.R', echo=TRUE)
View(Vezaiciai)
warnings()
View(ABL.sub)
dtudataload()
dtudataproces()
dtudatasubset()
dtutotals()
source("fun/s_wprodow.R")
source("fun/s_winjow.R")
source("fun/s_wprod.R")
source("fun/s_winj.R")
source("fun/s_fprodow.R")
source("fun/s_fprod.R")
source("fun/s_save_to_xlsx.R")
source('~/Rdata/overview-charts/generate-overview.R', echo=TRUE)
View(ABL.sub)
dtuwellprodchart(NSD.sub, "NSD9")
dtuwellprodchartow(Genciai, "GNC3")
Genciai <- GEN.sub
Genciai <- setkey(setDT(Genciai), Date_m, Well_N)[
CJ(Date_m=seq(min(Date_m), max(Date_m), by='1 month'),
Well_N=unique(Well_N))][is.na(QOM), QOM:=0][is.na(QWM), QWM:=0][is.na(QFM), QFM:=0][is.na(QIW), QIW:=0][is.na(QOD), QOD:=0][is.na(QWD), QWD:=0][is.na(QFD), QFD:=0][order(Well_N)]
mindate <- min(as.Date(Genciai$Date_m))
minyear <- year(mindate)+1
minlab <- as.Date(paste(minyear, 01, 01, sep = "-"))
maxdate <- max(as.Date(Genciai$Date_m))
maxyear <- year(maxdate)
maxlab <- as.Date(paste(maxyear, 01, 01, sep = "-"))
Genciai <- Genciai[order(as.Date(Genciai$Date_m, format="%Y-%m-%d")),]
Genciai = Genciai %>% group_by(Well_N) %>% mutate(CumOil=cumsum(QOM))
Genciai = Genciai %>% group_by(Well_N) %>% mutate(CumWat=cumsum(QWM))
Genciai = Genciai %>% group_by(Well_N) %>% mutate(CumF=cumsum(QFM))
Genciai = Genciai %>% group_by(Well_N) %>% mutate(CumInj=cumsum(QIW))
Genciai = Genciai %>% group_by(Date_m) %>% mutate(QOMF = sum(QOM))
Genciai = Genciai %>% group_by(Date_m) %>% mutate(QWMF = sum(QWM))
Genciai = Genciai %>% group_by(Well_N) %>% mutate(CumOilF=cumsum(QOMF))
dtuwellprodchartow(Genciai, "GNC3")
#loading required libraries
library(data.table)
library(ggplot2)
library(grid)
library(magrittr)
library(dplyr)
library(gtable)
library(ggthemes)
library(gridBase)
library(png)
library(gridExtra)
library(scales)
Genciai <- GEN.sub
Genciai <- setkey(setDT(Genciai), Date_m, Well_N)[
CJ(Date_m=seq(min(Date_m), max(Date_m), by='1 month'),
Well_N=unique(Well_N))][is.na(QOM), QOM:=0][is.na(QWM), QWM:=0][is.na(QFM), QFM:=0][is.na(QIW), QIW:=0][is.na(QOD), QOD:=0][is.na(QWD), QWD:=0][is.na(QFD), QFD:=0][order(Well_N)]
mindate <- min(as.Date(Genciai$Date_m))
minyear <- year(mindate)+1
minlab <- as.Date(paste(minyear, 01, 01, sep = "-"))
maxdate <- max(as.Date(Genciai$Date_m))
maxyear <- year(maxdate)
maxlab <- as.Date(paste(maxyear, 01, 01, sep = "-"))
Genciai <- Genciai[order(as.Date(Genciai$Date_m, format="%Y-%m-%d")),]
Genciai = Genciai %>% group_by(Well_N) %>% mutate(CumOil=cumsum(QOM))
Genciai = Genciai %>% group_by(Well_N) %>% mutate(CumWat=cumsum(QWM))
Genciai = Genciai %>% group_by(Well_N) %>% mutate(CumF=cumsum(QFM))
Genciai = Genciai %>% group_by(Well_N) %>% mutate(CumInj=cumsum(QIW))
Genciai = Genciai %>% group_by(Date_m) %>% mutate(QOMF = sum(QOM))
Genciai = Genciai %>% group_by(Date_m) %>% mutate(QWMF = sum(QWM))
Genciai = Genciai %>% group_by(Well_N) %>% mutate(CumOilF=cumsum(QOMF))
pgen3 <- dtuwellprodchartow(Genciai, "GEN3")
fprod <- dtufieldprodchartow(Genciai)
tail(NSD.sub)
tail(Nausodis)
source('~/Rdata/overview-charts/gnc-overview-chart.R', echo=TRUE)
tail(Ablinga)
source('~/Rdata/overview-charts/gnc-overview-chart.R', echo=TRUE)
source('~/Rdata/overview-charts/grk-overview-chart.R', echo=TRUE)
source('~/Rdata/overview-charts/generate-overview.R', echo=TRUE)
load("~/Rdata/.RData")
source('~/Rdata/scripts/functions.R', echo=TRUE)
source('~/Rdata/overview-charts/vez-overview-chart.R', echo=TRUE)
pvez4 <- dtuwellprodchartow(Vezaiciai, "VEZ4")
pvez11 <- dtuwellprodchartow(Vezaiciai, "VEZ4")
pvez11 <- dtuwellprodchartow(Vezaiciai, "VEZ11")
pvez <- dtuwellprodchartow(Vezaiciai, "VEZ13")
pvez <- dtuwellprodchartow(Vezaiciai, "VEZ13R")
pvez <- dtuwellprodchartow(Vezaiciai, "VEZ14")
pvez <- dtuwellprodchartow(Vezaiciai, "VEZ15")
pvez <- dtuwellprodchartow(Vezaiciai, "VEZ12")
pvez <- dtuwellprodchartow(Vezaiciai, "VEZ16")
pvez <- dtuwellprodchartow(Vezaiciai, "VEZ17")
pvez <- dtuwellprodchartow(Vezaiciai, "VEZ18")
pvez <- dtuwellprodchartow(Vezaiciai, "VEZ19")
pvez <- dtuwellprodchartow(Vezaiciai, "VEZ15R")
pvez <- dtuwellprodchartow(Vezaiciai, "VEZ15R1")
pvez <- dtuwellprodchartow(Vezaiciai, "VEZ16R1")
pvez <- dtuwellprodchartow(Vezaiciai, "VEZ20")
load("~/Rdata/.RData")
source('~/Rdata/scripts/functions.R', echo=TRUE)
library("ggplot2")
plot1 <- qplot(Date_m, QOIL, data = VEZ.sub, colour = Well_N, size = I(1.5)) + theme_bw() +theme(legend.position = 'right')
plot1
plot1 <- qplot(Date_m, QOD, data = VEZ.sub, colour = Well_N, size = I(1.5)) + theme_bw() +theme(legend.position = 'right')
plot1
plot1 <- qplot(Date_m, QOD, data = VEZ.sub, colour = Well_N, size = I(1.5)), geom="line" + theme_bw() +theme(legend.position = 'right')
plot1 <- qplot(Date_m, QOD, data = VEZ.sub, colour = Well_N, size = I(1.5), geom="line") + theme_bw() +theme(legend.position = 'right')
plot1
plot1 <- qplot(Date_m, QOD, data = VEZ.sub, colour = Well_N, geom="line") + theme_bw() +theme(legend.position = 'right')
plot1
plot1 <- qplot(Date_m, QOD, data = VEZ.sub[Well_N="VEZ20",], colour = Well_N, geom="line") + theme_bw() +theme(legend.position = 'right')
plot1 <- qplot(Date_m, QOD, data = VEZ.sub[Well_N="VEZ20"], colour = Well_N, geom="line") + theme_bw() +theme(legend.position = 'right')
plot1
VEZ.significant <- VEZ.sub[ which(Well_N="VEZ4" & Well_N="VEZ11" & Well_N="VEZ12" & Well_N="VEZ13" & Well_N="VEZ14" & Well_N="VEZ15" & Well_N="VEZ16" & Well_N="VEZ17" & Well_N="VEZ18" & Well_N="VEZ19" & Well_N="VEZ20")]
VEZ.significant <- VEZ.sub[ which(Well_N='VEZ4' & Well_N="VEZ11" & Well_N="VEZ12" & Well_N="VEZ13" & Well_N="VEZ14" & Well_N="VEZ15" & Well_N="VEZ16" & Well_N="VEZ17" & Well_N="VEZ18" & Well_N="VEZ19" & Well_N="VEZ20"), ]
VEZ.significant <- VEZ.sub[ which(Well_N=="VEZ4" & Well_N=="VEZ11" & Well_N=="VEZ12" & Well_N=="VEZ13" & Well_N=="VEZ14" & Well_N=="VEZ15" & Well_N=="VEZ16" & Well_N=="VEZ17" & Well_N=="VEZ18" & Well_N=="VEZ19" & Well_N=="VEZ20"), ]
vez.selected <- c("VEZ4","VEZ11","VEZ12","VEZ13","VEZ14","VEZ15","VEZ16","VEZ17","VEZ18","VEZ19","VEZ20")
VEZ.significant <- data[VEZ.sub$Well_N %in% vez.selected,]
vez.selected <- c("VEZ4","VEZ11","VEZ12","VEZ13","VEZ14","VEZ15","VEZ16","VEZ17","VEZ18","VEZ19","VEZ20")
VEZ.significant <- VEZ.sub$Well_N %in% vez.selected
plot1 <- qplot(Date_m, QOD, data = VEZ.significant, colour = Well_N, geom="line") + theme_bw() +theme(legend.position = 'right')
VEZ.significant <- dataframe(VEZ.sub$Well_N %in% vez.selected)
VEZ.sub$Well_N %in% vez.selected
data.frame(VEZ.sub$Well_N %in% vez.selected)
VEZ.significant <- VEZ.sub[VEZ.sub$Well_N %in% vez.selected, ]
qplot(Date_m, QOD, data = VEZ.significant, colour = Well_N, geom="line") + theme_bw() +theme(legend.position = 'right')
vez.selected <- c("VEZ4","VEZ11","VEZ12","VEZ14","VEZ15","VEZ16","VEZ17","VEZ18","VEZ19","VEZ20")
VEZ.significant <- VEZ.sub[VEZ.sub$Well_N %in% vez.selected, ]
qplot(Date_m, QOD, data = VEZ.significant, colour = Well_N, geom="line") + theme_bw() +theme(legend.position = 'right')
vez.selected <- c("VEZ4","VEZ11","VEZ12","VEZ14","VEZ15","VEZ16","VEZ17","VEZ19","VEZ20")
VEZ.significant <- VEZ.sub[VEZ.sub$Well_N %in% vez.selected, ]
qplot(Date_m, QOD, data = VEZ.significant, colour = Well_N, geom="line") + theme_bw() +theme(legend.position = 'right')
vez.selected <- c("VEZ4","VEZ11","VEZ14","VEZ15","VEZ16","VEZ17","VEZ19","VEZ20")
VEZ.significant <- VEZ.sub[VEZ.sub$Well_N %in% vez.selected, ]
qplot(Date_m, QOD, data = VEZ.significant, colour = Well_N, geom="line") + theme_bw() +theme(legend.position = 'right')
vez.selected <- c("VEZ4","VEZ11","VEZ15","VEZ16","VEZ17","VEZ19","VEZ20")
VEZ.significant <- VEZ.sub[VEZ.sub$Well_N %in% vez.selected, ]
qplot(Date_m, QOD, data = VEZ.significant, colour = Well_N, geom="line") + theme_bw() +theme(legend.position = 'right')
vez.selected <- c("VEZ4","VEZ11","VEZ15","VEZ16","VEZ17","VEZ19","VEZ20")
VEZ.significant <- VEZ.sub[VEZ.sub$Well_N %in% vez.selected, ]
qplot(Date_m, QOD, data = VEZ.significant, colour = Well_N, geom="line", size = I(1.25)) + theme_bw() +theme(legend.position = 'right')
qplot(Date_m, QOD, data = VEZ.significant, colour = Well_N, geom="line", size = I(1.1)) + theme_bw() +theme(legend.position = 'right')
qplot(Date_m, QOD, data = VEZ.significant, colour = Well_N, size = I(1.1)) + theme_bw() +theme(legend.position = 'right')
source('~/.active-rstudio-document', echo=TRUE)
qplot(Date_m, QOD, data = VEZ.significant, colour = Well_N, geom="line", size = I(1.1)) + theme_bw() +theme(legend.justification=c(0,0), legend.position=c(0,0))
qplot(Date_m, QOD, data = VEZ.significant, colour = Well_N, geom="line", size = I(1.1)) + theme_bw() +theme(legend.justification=c(0,0), legend.position=c(1,0))
qplot(Date_m, QOD, data = VEZ.significant, colour = Well_N, geom="line", size = I(1.1)) + theme_bw() +theme(legend.justification=c(1,0), legend.position=c(1,0))
qplot(Date_m, QOD, data = VEZ.significant, colour = Well_N, geom="line", size = I(1.1)) + theme_bw() +theme(legend.justification=c(0,1), legend.position=c(0,1))
#loading required libraries
library(data.table)
library(ggplot2)
library(grid)
library(magrittr)
library(dplyr)
library(gtable)
library(ggthemes)
library(gridBase)
library(png)
library(gridExtra)
library(scales)
Girkaliai <- GRK.sub
Girkaliai <- setkey(setDT(Girkaliai), Date_m, Well_N)[
CJ(Date_m=seq(min(Date_m), max(Date_m), by='1 month'),
Well_N=unique(Well_N))][is.na(QOM), QOM:=0][is.na(QWM), QWM:=0][is.na(QFM), QFM:=0][is.na(QIW), QIW:=0][is.na(QOD), QOD:=0][is.na(QWD), QWD:=0][is.na(QFD), QFD:=0][order(Well_N)]
mindate <- min(as.Date(Girkaliai$Date_m))
minyear <- year(mindate)+1
minlab <- as.Date(paste(minyear, 01, 01, sep = "-"))
maxdate <- max(as.Date(Girkaliai$Date_m))
maxyear <- year(maxdate)+1
maxlab <- as.Date(paste(maxyear, 01, 01, sep = "-"))
Girkaliai <- Girkaliai[order(as.Date(Girkaliai$Date_m, format="%Y-%m-%d")),]
Girkaliai = Girkaliai %>% group_by(Well_N) %>% mutate(CumOil=cumsum(QOM))
Girkaliai = Girkaliai %>% group_by(Well_N) %>% mutate(CumWat=cumsum(QWM))
Girkaliai = Girkaliai %>% group_by(Well_N) %>% mutate(CumF=cumsum(QFM))
Girkaliai = Girkaliai %>% group_by(Well_N) %>% mutate(CumInj=cumsum(QIW))
Girkaliai = Girkaliai %>% group_by(Date_m) %>% mutate(QOMF = sum(QOM))
Girkaliai = Girkaliai %>% group_by(Date_m) %>% mutate(QWMF = sum(QWM))
Girkaliai = Girkaliai %>% group_by(Well_N) %>% mutate(CumOilF=cumsum(QOMF))
pgrk5 <- dtuwellprodchartow(Girkaliai, "GRK5")
load("~/Rdata/.RData")
source('~/Rdata/scripts/functions.R', echo=TRUE)
source('~/Rdata/overview-charts/vez-overview-chart.R', echo=TRUE)
dtufieldprodchartow(Vezaiciai)
dtuwellinjchart(VEZ.sub, "VEZ12")
source('~/Rdata/fun/s_winjow.R', echo=TRUE)
dtuwellinjchartow(VEZ.sub, "VEZ12")
source('~/Rdata/fun/s_winjow.R', echo=TRUE)
dtuwellinjchartow(VEZ.sub, "VEZ12")
source('~/RData/scripts/subsetting-according-to-multiple-factors.R', echo=TRUE)
load("~/Rdata/.RData")
source('~/Rdata/scripts/functions.R', echo=TRUE)
source('~/RData/scripts/subsetting-according-to-multiple-factors.R', echo=TRUE)
qplot(Date_m, QOD, ylab = "Oil rate, m3/day", data = VEZ.significant, colour = Well_N, geom="line", size = I(1.1)) + theme_bw() +theme(legend.justification=c(0,1), legend.position=c(0,1))
qplot(Date_m, QOD, ylab = "Oil rate, m3/day", xlab = "Year", data = VEZ.significant, colour = Well_N, geom="line", size = I(1.1)) + theme_bw() +theme(legend.justification=c(0,1), legend.position=c(0,1))
colour1 <- c("darkgrey", "brown", "blue")
qplot(Date_m, QOD, ylab = "Oil rate, m3/day", xlab = "Year", data = VEZ.significant, colour = Well_N, geom="line", size = I(1.1)) + theme_bw() +theme(legend.justification=c(0,1), legend.position=c(0,1)) +
scale_colour_manual(values=colour1)
c25 <- c("dodgerblue2","#E31A1C", # red
"green4",
"#6A3D9A", # purple
"#FF7F00", # orange
"black","gold1",
"skyblue2","#FB9A99", # lt pink
"palegreen2",
"#CAB2D6", # lt purple
"#FDBF6F", # lt orange
"gray70", "khaki2",
"maroon","orchid1","deeppink1","blue1","steelblue4",
"darkturquoise","green1","yellow4","yellow3",
"darkorange4","brown")
vez.selected <- c("VEZ4")
VEZ.significant <- VEZ.sub[VEZ.sub$Well_N %in% vez.selected, ]
qplot(Date_m, QOD, ylab = "Oil rate, m3/day", xlab = "Year", data = VEZ.significant, colour = Well_N, geom="line", size = I(1.1)) + theme_bw() +theme(legend.justification=c(0,1), legend.position=c(0,1)) +
scale_colour_manual(values=c25)
vez.selected <- c("VEZ4", "VEZ11")
VEZ.significant <- VEZ.sub[VEZ.sub$Well_N %in% vez.selected, ]
qplot(Date_m, QOD, ylab = "Oil rate, m3/day", xlab = "Year", data = VEZ.significant, colour = Well_N, geom="line", size = I(1.1)) + theme_bw() +theme(legend.justification=c(0,1), legend.position=c(0,1)) +
scale_colour_manual(values=c25)
vez.selected <- c("VEZ11", "VEZ4")
VEZ.significant <- VEZ.sub[VEZ.sub$Well_N %in% vez.selected, ]
qplot(Date_m, QOD, ylab = "Oil rate, m3/day", xlab = "Year", data = VEZ.significant, colour = Well_N, geom="line", size = I(1.1)) + theme_bw() +theme(legend.justification=c(0,1), legend.position=c(0,1)) +
scale_colour_manual(values=c25)
vez.selected <- c("VEZ11", "VEZ4")
VEZ.significant <- VEZ.sub[VEZ.sub$Well_N %in% vez.selected, ]
qplot(Date_m, QOD, ylab = "Oil rate, m3/day", xlab = "Year", data = VEZ.significant, colour = Well_N, geom="line", size = I(1.1)) + theme_bw() +theme(legend.justification=c(0,1), legend.position=c(0,1)) +
scale_colour_manual(values=c25)
VEZ.significant <- droplevels(VEZ.significant)
qplot(Date_m, QOD, ylab = "Oil rate, m3/day", xlab = "Year", data = VEZ.significant, colour = Well_N, geom="line", size = I(1.1)) + theme_bw() +theme(legend.justification=c(0,1), legend.position=c(0,1)) +
scale_colour_manual(values=c25)
vez.selected <- c("VEZ4")
VEZ.significant <- VEZ.sub[VEZ.sub$Well_N %in% vez.selected, ]
VEZ.significant <- droplevels(VEZ.significant)
qplot(Date_m, QOD, ylab = "Oil rate, m3/day", xlab = "Year", data = VEZ.significant, colour = Well_N, geom="line", size = I(1.1)) + theme_bw() +theme(legend.justification=c(0,1), legend.position=c(0,1)) +
scale_colour_manual(values=c25)
vez.selected <- c("VEZ4", "VEZ11")
VEZ.significant <- VEZ.sub[VEZ.sub$Well_N %in% vez.selected, ]
VEZ.significant <- droplevels(VEZ.significant)
qplot(Date_m, QOD, ylab = "Oil rate, m3/day", xlab = "Year", data = VEZ.significant, colour = Well_N, geom="line", size = I(1.1)) + theme_bw() +theme(legend.justification=c(0,1), legend.position=c(0,1)) +
scale_colour_manual(values=c25)
VEZ.ss <- factor(VEZ.significant$Well_N, levels = VEZ.significant[order(VEZ.significant$Well_N), "Well name"])
VEZ.significant <- factor(VEZ.significant$Well_N, levels = VEZ.significant[order(VEZ.significant$Well_N), "Well name"])
VEZ.significant <- VEZ.sub[VEZ.sub$Well_N %in% vez.selected, ]
vez.selected <- c("VEZ4", "VEZ11")
VEZ.significant <- VEZ.sub[VEZ.sub$Well_N %in% vez.selected, ]
VEZ.significant <- droplevels(VEZ.significant)
VEZ.significant$Well_N <- factor(VEZ.significant$Well_N, levels = VEZ.significant[order(VEZ.significant$Well_N), "Well name"])
vez.4 <- c("VEZ4")
VEZ.4 <- VEZ.sub[VEZ.sub$Well_N %in% vez.selected, ]
VEZ.4 <- droplevels(VEZ.significant)
qplot(Date_m,
QOD,
ylab = "Oil rate, m3/day",
xlab = "Year",
data = VEZ.4,
colour = Well_N,
geom="line",
size = I(1.1)) +
theme_bw() +theme(legend.justification=c(0,1), legend.position=c(0,1)) +
scale_colour_manual(values=c25)
vez.selected <- c("VEZ4")
VEZ.significant <- VEZ.sub[VEZ.sub$Well_N %in% vez.selected, ]
VEZ.significant <- droplevels(VEZ.significant)
qplot(Date_m,
QOD,
ylab = "Oil rate, m3/day",
xlab = "Year",
data = VEZ.significant,
colour = Well_N,
geom="line",
size = I(1.1)) +
theme_bw() +theme(legend.justification=c(0,1), legend.position=c(0,1)) +
scale_colour_manual(values=c25)
vez.selected <- c("VEZ11", "VEZ4")
VEZ.significant <- VEZ.sub[VEZ.sub$Well_N %in% vez.selected, ]
VEZ.significant <- droplevels(VEZ.significant)
qplot(Date_m,
QOD,
ylab = "Oil rate, m3/day",
xlab = "Year",
data = VEZ.significant,
colour = Well_N,
geom="line",
size = I(1.1)) +
theme_bw() +theme(legend.justification=c(0,1), legend.position=c(0,1)) +
scale_colour_manual(values=c25)
View(VEZ.significant)
unique(VEZ.selected$Well_N)
unique(VEZ.ignificant$Well_N)
unique(VEZ.significant$Well_N)
qplot(Date_m,
QOD,
ylab = "Oil rate, m3/day",
xlab = "Year",
data = VEZ.significant,
colour = Well_N,
geom="line",
stat = "Well_N"
size = I(1.1)) +
theme_bw() +theme(legend.justification=c(0,1), legend.position=c(0,1)) +
scale_colour_manual(values=c25)
qplot(Date_m,
QOD,
ylab = "Oil rate, m3/day",
xlab = "Year",
data = VEZ.significant,
colour = Well_N,
geom="line",
stat = "Well_N",
size = I(1.1)) +
theme_bw() +theme(legend.justification=c(0,1), legend.position=c(0,1)) +
scale_colour_manual(values=c25)
library("plyr")
library("dplyr")
VEZ.significant[ order(VEZ.significant$Well_N), ]
qplot(Date_m,
QOD,
ylab = "Oil rate, m3/day",
xlab = "Year",
data = VEZ.significant,
colour = Well_N,
geom="line",
stat = "Well_N",
size = I(1.1)) +
theme_bw() +theme(legend.justification=c(0,1), legend.position=c(0,1)) +
scale_colour_manual(values=c25)
qplot(Date_m,
QOD,
ylab = "Oil rate, m3/day",
xlab = "Year",
data = VEZ.significant,
colour = Well_N,
geom="line",
size = I(1.1)) +
theme_bw() +theme(legend.justification=c(0,1), legend.position=c(0,1)) +
scale_colour_manual(values=c25)
vez.selected <- c("VEZ4", "VEZ11")
VEZ.significant <- VEZ.sub[VEZ.sub$Well_N %in% vez.selected, ]
VEZ.significant <- droplevels(VEZ.significant)
VEZ.significant[ order(VEZ.significant$Well_N), ]
qplot(Date_m,
QOD,
ylab = "Oil rate, m3/day",
xlab = "Year",
data = VEZ.significant,
colour = Well_N,
geom="line",
size = I(1.1)) +
theme_bw() +theme(legend.justification=c(0,1), legend.position=c(0,1)) +
scale_colour_manual(values=c25)
VEZ.significant <- VEZ.significant[ order(VEZ.significant$Well_N), ]
qplot(Date_m,
QOD,
ylab = "Oil rate, m3/day",
xlab = "Year",
data = VEZ.significant,
colour = Well_N,
geom="line",
size = I(1.1)) +
theme_bw() +theme(legend.justification=c(0,1), legend.position=c(0,1)) +
scale_colour_manual(values=c25)
source('~/RData/scripts/subsetting-according-to-multiple-factors.R', echo=TRUE)
library(gtools)
VEZ.significant$Well_N <- factor(VEZ.significant$Well_N, levels = mixedsort(levels(VEZ.significant$Well_N)))
qplot(Date_m,
QOD,
ylab = "Oil rate, m3/day",
xlab = "Year",
data = VEZ.significant,
colour = Well_N,
geom="line",
size = I(1.1)) +
theme_bw() +theme(legend.justification=c(0,1), legend.position=c(0,1)) +
scale_colour_manual(values=c25)
vez.selected <- c("VEZ4", "VEZ11")
VEZ.significant <- VEZ.sub[VEZ.sub$Well_N %in% vez.selected, ]
VEZ.significant <- droplevels(VEZ.significant)
VEZ.significant$Well_N <- factor(VEZ.significant$Well_N, levels = mixedsort(levels(VEZ.significant$Well_N)))
qplot(Date_m,
QOD,
ylab = "Oil rate, m3/day",
xlab = "Year",
data = VEZ.significant,
colour = Well_N,
geom="line",
size = I(1.1)) +
theme_bw() +theme(legend.justification=c(0,1), legend.position=c(0,1)) +
scale_colour_manual(values=c25)
source('~/RData/scripts/subsetting-according-to-multiple-factors.R', echo=TRUE)
VEZ.significant$levels <- VEZ.significant$Well_N
VEZ.sub1 <- VEZ.sub
VEZ.sub1$levels <- VEZ.sub1$Well_N
source('~/RData/scripts/subsetting-according-to-multiple-factors.R', echo=TRUE)
source('~/.active-rstudio-document', echo=TRUE)
source('~/RData/scripts/subsetting-according-to-multiple-factors.R', echo=TRUE)
source('~/.active-rstudio-document', echo=TRUE)
pie(rep(1,n), col=c25)
c25
barplot(seq(1:25), col=c25)
legend()
pal=c25
pie(rep(1, length(pal)), labels = sprintf("%d (%s)", seq_along(pal),
pal), col = pal)
source('~/.active-rstudio-document', echo=TRUE)
savehistory("~/RData/123.R")
