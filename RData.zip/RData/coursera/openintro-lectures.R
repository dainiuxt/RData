download.file("http://www.openintro.org/stat/data/mlb11.RData",
              destfile = "mlb11.RData")
load("mlb11.RData")
