piedata <- subset(monthly, monthly$Date_m=="2016-04-01")
piedata$percentage <- round(piedata$QOM/sum(piedata$QOM)*100)
piedata$labels <- paste(piedata$Well_N, piedata$percentage, "%", '\n', round(piedata$QOD, digits = 1), "m3/d", sep = " ")
piedata <- piedata[order(-piedata$percentage),]
