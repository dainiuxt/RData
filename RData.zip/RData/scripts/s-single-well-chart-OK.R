p1 <- ggplot(data=monthly %>% filter(Well_N == "VEZ15R1"),
             aes_string(x = "Date_m")) +
  xlab("") +
  ylab("Flowrate, m3/day") +
  # ggtitle(wellname) +
  theme_bw() +
  #      discrete_scale("colour", "mycolours" , mycolours) +
  geom_line(aes(y = QFD, col = "Fluidas, m3/d")) +
  geom_line(aes(y = QOD, col = "Nafta, m3/d")) +
  geom_point(aes(y = QOD, col = "Nafta, m3/d")) +
  geom_line(aes(y = QWD, col = "Vanduo, m3/d")) +
  #     scale_colour_tableau() +
  scale_colour_manual(values=colour1) +
  scale_x_date(breaks = date_breaks("year"),
               labels = date_format("%Y")) +
  annotate("text", x=as.Date(minlab, "%Y-%m-%d"), y = ypos, label = wellname) +
  theme(legend.position = "none",
        legend.title = element_blank(),
        panel.grid.major = element_line(colour = "darkgrey", size = 0),
        panel.grid.minor = element_line(colour = "darkgrey", linetype = "dotted"))
#   theme(plot.title)
#   geom_text(aes(data = Nausodis, .1, .1, label = "NSD3R"))

p1
