#Screen output
factorchart <- plot(LIZ.sub$CumOil, LIZ.sub$WCT, type="n", ylim=c(0,100))
grid(NULL, NULL)
points(LIZ.sub$CumOil, LIZ.sub$WCT, pch=19, col=LIZ.sub$Well_N)
legend("bottomright", legend = levels(LIZ.sub$Well_N), pch = 19, col=1:length(LIZ.sub$Well_N), title = "Well")
factorchart

#high-res PNG output
dev.copy(png,
         filename = "GRK-CumOil-vs-WCT.png",
         res = 600,
         units = "in",
         height = 8,
         width = 11)
dev.off()

# png("GRK-CumOil-vs-WCT.png", width = 11, height = 8, units = "in", res = 600)
# plot(LIZ.sub$CumOil, LIZ.sub$WCT, type="n")
# points(LIZ.sub$CumOil, LIZ.sub$WCT, pch=19, col=LIZ.sub$Well_N)
# legend("bottomright", legend = levels(LIZ.sub$Well_N), pch = 19, col=1:length(LIZ.sub$Well_N), title = "Well")
# dev.off()
