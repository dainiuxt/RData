dev.copy(png,
         filename = "vez20.png",
         res = 300,
         units = "in",
         height = 8,
         width = 11)
dev.off()
