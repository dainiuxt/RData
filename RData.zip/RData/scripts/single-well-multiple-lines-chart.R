#pdf(file = "gavyba-%03d.pdf", onefile = FALSE, height = 600, width = 800)
ggtitle("Chart title")
ggplot(VEZ.sub[VEZ.sub$Well_N == "VEZ15R1",], aes(Date_m)) +
  geom_line(aes(y = QOD, colour = "Oil")) +
  geom_line(aes(y = QWD, colour = "Water"))
ggplot(monthly[monthly$Well_N == "ABL2",], aes(Date_m)) +
  geom_line(aes(y = QOM, colour = "Oil")) +
  geom_line(aes(y = QWM, colour = "Water"))
#dev.off()
