#install packages after update
install.packages(c("ggplot2", "zoo", "dplyr", "swirl", "RODBC", "Cairo", "data.table", "DBI", "highr", "knitr", "lattice", "shiny", "spatial", "XLConnect"))
