overview <- with(monthly, monthly[(Date_m == "2015-11-01"),])
dtu_save.xlsx("2015-11-30-overview.xlsx", overview)
