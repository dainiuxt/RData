c25 <- c("dodgerblue2", #VEZ4
         "#E31A1C", # red VEZ11
         #"green4", #VEZ12
         #"#6A3D9A", # purple VEZ13
         #"black", #VEZ13R
         #"#FF7F00", # orange VEZ14
         "gold1", #VEZ15
         #"#FDBF6F", # lt orange VEZ15R1
         "skyblue2", #VEZ16
         #"gray70", #VEZ16R1
         "#FB9A99", # lt pink VEZ17
         #"palegreen2", #VEZ18
         "#CAB2D6", # lt purple VEZ19
         "khaki2", #VEZ20
         "maroon",
         "orchid1",
         "deeppink1",
         "blue1",
         "steelblue4",
         "darkturquoise",
         "green1",
         "yellow4",
         "yellow3",
         "darkorange4",
         "brown")

vez.selected <- c("VEZ4", "VEZ11", "VEZ15", "VEZ16", "VEZ17", "VEZ19", "VEZ20")

VEZ.significant <- VEZ.sub[VEZ.sub$Well_N %in% vez.selected, ]
VEZ.significant <- droplevels(VEZ.significant)
VEZ.significant$Well_N <- factor(VEZ.significant$Well_N,
                                 levels = mixedsort(levels(VEZ.significant$Well_N)))

qplot(Date_m,
      QOD,
      ylab = "Oil rate, m3/day",
      xlab = "Year",
      data = VEZ.significant,
      col = Well_N,
      geom="line",
      size = I(1.1)) +
  theme_bw() +
  theme(legend.justification=c(0,1),
        legend.position=c(0,1),
        legend.title = element_blank()) +
  scale_colour_manual(values=c25)
