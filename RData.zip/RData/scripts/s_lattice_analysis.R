library("lattice")
latplot <- xyplot(WCT ~ CumOil | factor(Well_N), data = VEZ.sub[VEZ.sub$Well_N=="VEZ17",])
latplot <- xyplot(WCT ~ CumOil | factor(Well_N), data = LIZ.sub)
latplot

xyplot(WCT ~ QOM | factor(Well_N), data = VEZ.sub[VEZ.sub$Well_N=="VEZ17",])
